using System;

namespace hashcode2019 {

    public class Config {

        public string Name { get; set;}
        public string InputPath { get; set;}
        public string OutputPath { get; set;}

    }

}